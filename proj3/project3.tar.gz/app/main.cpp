// main.cpp
// ICS45C Fall 2020 Project 3
// Name: Keyu Zhang
// ID: 19898090
// UCINetID: keyuz4

#include "commands.hpp"

int main()
{
    Commands CommandService;
    CommandService.mainLoop();

    return 0;
}
